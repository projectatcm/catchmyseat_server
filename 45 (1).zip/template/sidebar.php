  <!-- left side start-->
  <div class="left-side sticky-left-side">

    <!--logo and iconic logo start-->
    <div class="logo" style="height:60px; padding: 6px;">					
        <img src="assets/images/logo.png" height="100%;" style="object-fit:cover;" />
    </div>
    <div class="logo-icon text-center">
        <a href="index.html"><i class="lnr lnr-home"></i> </a>
    </div>

    <!--logo and iconic logo end-->
    <div class="left-side-inner">

        <!--sidebar nav start-->
        <ul class="nav nav-pills nav-stacked custom-nav">
            <li class="active"><a href="index.html"><i class="lnr lnr-power-switch"></i><span>Dashboard</span></a>
            </li>
            <li>
                <a href="passengers.php"><i class="lnr lnr-power-switch"></i><span>Passengers</span></a>
            </li>
            <li>
                <a href="drivers.php"><i class="lnr lnr-power-switch"></i><span>Drivers</span></a>
            </li>
             <li >
                <a href="logout.php"><i class="lnr lnr-power-switch"></i><span>Logout</span></a>
            </li>
        </ul>

    </div>
</div>
        <!-- left side end-->